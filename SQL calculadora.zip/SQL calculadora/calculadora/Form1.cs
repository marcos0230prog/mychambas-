﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Operaciones obj = new Operaciones();
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(!obj.isnumeric(txt_num1.Text) && !obj.isnumeric(txt_num2.Text))
            {
                txt_resultado.Text = "INGRESE UN VALOR VADLIDO";
            }
            else
            {
                int suma = obj.suma(Convert.ToInt32(txt_num1.Text), Convert.ToInt32(txt_num2.Text));
                txt_resultado.Text=Convert.ToString(suma);
            }

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btn_restar_Click(object sender, EventArgs e)
        {
            if (!obj.isnumeric(txt_num1.Text) && !obj.isnumeric(txt_num2.Text))
            {
                txt_resultado.Text = "INGRESE UN VALOR VADLIDO";
            }
            else
            {
                int resta = obj.resta(Convert.ToInt32(txt_num1.Text), Convert.ToInt32(txt_num2.Text));
                txt_resultado.Text = Convert.ToString(resta);
            }
        }

        private void btn_multiplicar_Click(object sender, EventArgs e)
        {
            if (!obj.isnumeric(txt_num1.Text) && !obj.isnumeric(txt_num2.Text))
            {
                txt_resultado.Text = "INGRESE UN VALOR VADLIDO";
            }
            else
            {
                int multiplicar = obj.multiplicar(Convert.ToInt32(txt_num1.Text), Convert.ToInt32(txt_num2.Text));
                txt_resultado.Text = Convert.ToString(multiplicar);
            }
        }

        private void btn_division_Click(object sender, EventArgs e)
        {
            if (!obj.isnumeric(txt_num1.Text) && !obj.isnumeric(txt_num2.Text))
            {
                txt_resultado.Text = "INGRESE UN VALOR VADLIDO";
            }
            else
            {
                int division = obj.division(Convert.ToInt32(txt_num1.Text), Convert.ToInt32(txt_num2.Text));
                txt_resultado.Text = Convert.ToString(division);
            }
        }
    }
}
